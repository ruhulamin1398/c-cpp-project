
void Search()
{

    cout<<"\t\t\t\t\t----- Search -----"<<endl<<endl<<endl;

    FILE *fp;
    struct Person a;
    fp=fopen("file.txt","ab+");



        cout<<"Enter Id : ";
        int id;
        cin>>id;
        fseek(fp,0,SEEK_SET);
        int ind=0;

        while(fread(&a,sizeof(a),1,fp)==1)
        {
            if(id==a.Id)
            {
                cout<<"\t-----******--------"<<endl;
                cout<<"ID       : "<<a.Id<<endl;
                cout<<"Catagory : "<<a.Catagory<<endl;
                cout<<"Name     : "<<a.Name<<endl;
                cout<<"Address  : "<<a.Address<<endl;
                cout<<"Contact  : "<<a.Contact<<endl;
                cout<<"\t-----******--------"<<endl;
                ind=1;
                break;
            }


        }
        if(ind==0 )
            cout<<" \t\tData Not Found  !!!!!!"<<endl<<endl;
        cout<<"\t1. Search Again"<<endl;
        cout<<endl<<"\t2. Return Home Page"<<endl;
        cout<<"Enter Your Choice"<<" : ";
        cin>>temp;
        if(temp==1)
            Search();
        else
            HomePage();




}
