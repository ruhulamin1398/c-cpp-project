//
//void Remove()
//{
//
//    cout<<"\t\t\t\t\t----- REMOVE -----"<<endl<<endl<<endl;
//    cout<<"\t Enter Id : ";
//    int id;
//    cin>>id;
//
//    FILE *fp;
//
//    struct Person a;
//    fp=fopen("file.txt","w+");
//    fseek(fp,0,SEEK_SET);
//    int ind=0 ;
//    while(fread(&a,sizeof(a),1,fp)==1)
//    {
//
//        if(id==a.Id)
//        {
//            ind=1;
//            break;
//        }
//
//    }
//    if(ind==0)
//    {
//        system("cls");
//        cout<<"\t\t Not Found !!!!!!  Try Again ";
//
//    }
//    else
//    {
//        cout<<" Name : "<<a.Name<<endl;
//        cout<<"\tSure Want To Delete"<<endl;
//        cout<<endl<<"\t1. Yes"<<endl;
//        cout<<endl<<"\t1. No"<<endl;
//        cout<<"\t2. Return Home Page"<<endl;
//        cout<<"Enter Your Choice"<<" : ";
//        cin>>temp;
//        if(temp==1)
//        {
//            FILE *ft;
//            ft=fopen("test.txt","w+");
//            fseek(fp,0,SEEK_SET);
//            fseek(ft,0,SEEK_SET);
//            while(fread(&a,sizeof(a),1,fp)==1)
//            {
//                if(a.Id!=id)
//                {
//                    fseek(ft,0,SEEK_CUR);
//                    fwrite(&a,sizeof(a),1,ft);
//                }
//            }
//            fclose(ft);
//            fclose(fp);
//            remove("file.txt");
//
//
//            rename("test.dat","file.txt");
//
//            remove("test.text");
//            fp=fopen("file.txt","r+");
//
//        }
//        else if(temp==2)
//            Remove();
//            else
//                HomePage();
//    }
//
//}
void Remove(){;;;;;;;};
