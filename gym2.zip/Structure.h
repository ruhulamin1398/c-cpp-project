 struct Person{

int Id;
string Catagory;
string Name;
string Address;
string Contact;

};
