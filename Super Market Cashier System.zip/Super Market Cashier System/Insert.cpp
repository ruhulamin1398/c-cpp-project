
void Insert() {



    item["0120001"]= make_pair("milk",10.50);
    item["0120002"]= make_pair("Bread",05.50);
    item["0120003"]= make_pair("Chocolate",08.00);
    item["0120004"]= make_pair("Towel",12.10);
    item["0120005"]= make_pair("Toothpaste",06.75);
    item["0120006"]= make_pair("Soap",05.20);
    item["0120007"]= make_pair("Pen",02.00);
    item["0120008"]= make_pair("Biscuits",04.45);
    item["0120009"]= make_pair("Lamp",20.50);
    item["0120010"]= make_pair("Battery",10.00);

//    item[0].name="Milk";
//    item[0].barcode="0120001";
//    item[0].price= 10.5;
//
//    item[1].name="Bread";
//    item[1].barcode="0120002";
//    item[1].price= 05.50;
//
//    item[2].name="Chocolate";
//    item[2].barcode="0120003";
//    item[3].price= 08.00;
//
//    item[3].name="Towel";
//    item[3].barcode="0120004";
//    item[3].price= 12.10;
//
//    item[4].name="Toothpaste";
//    item[4].barcode="0120005";
//    item[4].price= 106.75;
//
//    item[5].name="Soap";
//    item[5].barcode="0120006";
//    item[5].price= 05.20;
//
//    item[6].name="Pen";
//    item[6].barcode="0120007";
//    item[6].price= 02.00;
//
//    item[7].name="Biscuits";
//    item[7].barcode="0120008";
//    item[7].price= 04.45;
//
//    item[8].name="Lamp";
//    item[8].barcode="0120009";
//    item[8].price= 20.50;
//
//    item[9].name="Battery";
//    item[9].barcode="0120010";
//    item[9].price= 10.00;




}
