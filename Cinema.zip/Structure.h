struct ticket{

    char name[101] ;
    int id=0;
    char phone[101] ;
    int movie_id =0;
    char time[101]="6 PM";
    int price=400;
};
