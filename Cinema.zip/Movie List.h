void movies(){


    system("cls");
cout<<"\t****** TODAY MOVIE LIST ******"<<endl<<endl;
for( int i=1 ; i<=total_movie; i++)
    cout<<i<<". "<<movielist[i]<<endl;

cout<<endl<<endl;
cout<<endl<<endl<<"Press Any Key to Hompe Page"<<endl;
getchar();
getchar();

Home();
}
