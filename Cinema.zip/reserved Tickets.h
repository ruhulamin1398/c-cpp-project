
void reserved(){


    system("cls");
    FILE *fp;
    struct ticket temp;
    fp=fopen("ticket.dat","ab+");
    fseek(fp,0,SEEK_SET);


    while(fread(&temp,sizeof(temp),1,fp)==1)
    {
        cout<<"\t-----******--------"<<endl;
        cout<<"ID       : "<<temp.id<<endl;
        cout<<"Movie    : "<<movielist[temp.movie_id]<<endl;
        cout<<"Name     : "<<temp.name<<endl;
        cout<<"Phone    : "<<temp.phone<<endl;
        cout<<"Time    : "<<temp.time<<endl;

    }
    fclose(fp);

    cout<<endl<<endl;
cout<<endl<<endl<<"Press Any Key to Hompe Page"<<endl;
getchar();
getchar();

Home();

}
