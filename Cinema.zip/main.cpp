#include<bits/stdc++.h>
#include<stdio.h>
using namespace std;

int total_movie=4;
string movielist[5]= {" ","The Godfather","Schindler's List","Raging Bull","Vertigo" };


void Home();
#include "Structure.h";
#include "Movie List.h";
#include "Buy Ticket.h";
#include "reserved Tickets.h";
#include "Cancel Ticket.h"



int main()
{

    cout<<"\t\t\t\t\t\tWelcome to ABC Cinema"<<endl;

    Home();
    return 0 ;
}


void Home()
{
    system("cls");
    cout<<"\t\t\t\t\t----- Main Menu -----"<<endl<<endl<<endl;

    cout<<"\t\t1. Movie List"<<endl;
    cout<<"\t\t2. Buy Ticket"<<endl;
    cout<<"\t\t3. reserved Tickets"<<endl;
    cout<<"\t\t4. Cancel Ticket"<<endl;
    cout<<"\t\t5. Close App"<<endl<<endl<<endl;
    cout<<"Enter Your Choice"<<" : ";

    switch(getchar())
    {
    case '1':
        movies();
        break;
    case '2':
        buy();
        break;
    case '3':
        reserved();
        break;
    case '4':
        cencel();
    case '5':
        exit(0);
    default:
        Home();
    }

}


