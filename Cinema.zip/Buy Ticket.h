void buy()
{
    system("cls");

    cout<<"\t****** BUY TICKET ******"<<endl<<endl;
    cout<<"Note: Show time 6 PM only "<<endl;
    cout<<"Note: price 400 Taka "<<endl<<endl;
    struct ticket newticket;

    cout<<"\t SELECT MOVIE :  "<<endl<<endl;
    for( int i=1 ; i<=total_movie; i++)
        cout<<i<<". "<<movielist[i]<<endl;

    cout<<"Enter Your Choice"<<" : ";
    cin>>newticket.movie_id;

    cout<<endl<<endl<<"------ You are selected "<<movielist[newticket.movie_id]<<" ----- "<<endl;
    cout<<"Enter Your Name : ";
    cin>>newticket.name;
    cout<<"Enter Your Phone : ";
    cin>>newticket.phone;





    FILE *fp;
    fp=fopen("ticket.dat","ab+");

    struct ticket temp;
    fseek(fp,0,SEEK_SET);
    int lastid=0;
    while(fread(&temp,sizeof(temp),1,fp)==1)
    {
        lastid=temp.id;

    }
    newticket.id=lastid+1;
    fseek(fp,0,SEEK_END);
    fwrite(&newticket,sizeof(newticket),1,fp);
    fclose(fp);

    cout<<endl<<"\t Congratulation you buy this ticket successfully"<<endl;
    cout<<endl<<"\t Your tickt id is "<<newticket.id<<endl;
        cout<<endl<<"1. Buy Again"<<endl;
    cout<<"2. Return Home Page"<<endl;
    cout<<"Enter Your Choice"<<" : ";
    int tmp;
    cin>>tmp;
    if(tmp==1)
        buy();
    else
        Home();













}
