 struct Person{

int Id;
char Catagory[101];
char Name[101];
char Address[101];
char Contact[101];

};
