


void viewstaff()
{
    int i=0,j;
    system("cls");
    gotoxy(1,1);
    printf("\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdbMember List\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb");
    gotoxy(0,2);
    int linen=95;
    while(linen--)
        printf("-");

    gotoxy(1,3);
    printf("| CATAGORY");
    gotoxy(20,3);
    printf("| ID");
    gotoxy(30,3);
    printf("| NAME");
    gotoxy(48,3);
    printf("| ADDRESS");
    gotoxy(65,3);
    printf("| CONTACT");
    gotoxy(80,3);
    printf("| MEMBER SINCE");
            gotoxy(95,3);
        printf("|");

    gotoxy(0,4);

    linen=95;
    while(linen--)
        printf("-");

    j=5;
    fp=fopen("stf.dat","rb");
    while(fread(&a,sizeof(a),1,fp)==1)
    {
        gotoxy(1,j);
        printf("|  %s",a.cat);
        gotoxy(20,j);
        printf("|  %d",a.id);
        gotoxy(30,j);
        printf("|  %s",a.name);
        gotoxy(48,j);
        printf("|  %s",a.Address);
        gotoxy(65,j);
        printf("|  %i",a.contact);
        gotoxy(80,j);
        printf("|  %s",a.membersince);
        gotoxy(95,j);
        printf("|");
        j+=2;

        gotoxy(0,j-1);
        linen=95;
        while(linen--)
            printf("-");

    }
    fclose(fp);
    gotoxy(35,j+3);
    returnfunc();
}
