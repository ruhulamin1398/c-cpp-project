#include<windows.h>/// for coordinate
#include<stdio.h>
//   #include<conio.h>  /// for getch()
//  #include <stdlib.h>
#include<string.h>
// #include<ctype.h>
#include<dos.h>
#include<time.h>
#define RETURNTIME 15

void returnfunc();
void addstaff();
void deletestaff();
void searchstaff();
void viewstaff();
void closeapplication();
int  getdata();
int  checkid(int);
int t();
void Password();
void issuerecord();
void loaderanim();

char catagories[][15]= {"New Member","Coach","Staff"};
FILE *fp,*ft,*fs;
int s;
char findstaff;
char password[10]= {"1234"};
struct staff a;

#include "style.h"
#include "structure.h"
#include "create.h"
#include "read.h"
#include "delete.h"
#include "search.h"
int main()
{
    Password();
    getch();
    return 0;
}

void mainmenu()
{
    system("cls");
    int i;
    gotoxy(20,3);
    printf(" \t\tMAIN MENU \n ");
    printf("\t\t\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\n");
    gotoxy(20,5);
    printf("<1> Add Members   ");
    gotoxy(20,7);
    printf("<2> Remove Members");
    gotoxy(20,9);
    printf("<3> Search Members");
    gotoxy(20,11);
    printf("<4> View Member's list");
    gotoxy(20,13);
    printf("<5> Close Application");
    gotoxy(20,20);
    t();
    gotoxy(20,18);
    printf("Enter your choice:");
    switch(getch())
    {
    case '1':
        addstaff();
        break;
    case '2':
        deletestaff();
        break;
    case '3':
        searchstaff();
        break;
    case '4':
        viewstaff();
        break;

    case '5':
    {
        system("cls");
        gotoxy(16,3);
        printf("\tGYM Management System");
        gotoxy(16,4);
        printf("\tProject in C");
        exit(0);
    }
    default:
    {
        gotoxy(10,25);
        printf("\aWrong Entry!!Please re-entered correct option");
        if(getch())
            mainmenu();
    }
}
}
void returnfunc()
{
    {
 //       gotoxy(15,2);
        printf("Press ENTER to return to main menu");
    }
a:
    if(getch()==13)
        mainmenu();
    else
        goto a;
}

int t(void)
{
    time_t t;
    time(&t);
    printf("Date and time:%s\n",ctime(&t));
    return 0 ;
}
void Password(void)
{
    system("cls");
    char d[25]="Password Protected";
    char ch,pass[10];
    int i=0,j;
    printf("\t\t\t\tWELCOME\n\t\t\t\t  To \n\t\t   \xdb\xdb\xdb\xdb\xdb\xdb GYM Management System \xdb\xdb\xdb\xdb\xdb\xdb\n");
    printf("\t \n\n\n Enter Password:");
    while(ch!=13)
    {
        ch=getch();
        if(ch!=13 && ch!=8)
        {
            putch('*');
            pass[i] = ch;
            i++;
        }
    }
    pass[i] = '\0';
    if(strcmp(pass,password)==0)
    {

        mainmenu();
    }
    else
    {
        printf("\n\n\n\t\t\aWarning!! \n\t   Incorrect Password \n\t Try again\n");
        getch();
        Password();
    }
}
