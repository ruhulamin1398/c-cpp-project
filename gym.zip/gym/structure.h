struct meroDate
{
    int mm,dd,yy;
};

struct staff
{
    int id;
    char stname[20];
    char name[20];
    char Address[20];
    char membersince[10];
    int contact;
    int count;
    char *cat;
    struct meroDate issued;
    struct meroDate duedate;

};
