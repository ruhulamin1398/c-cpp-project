
void deletestaff()
{
    system("cls");
    int d;
    char another='y';
    while(another=='y')
    {
        system("cls");
        gotoxy(10,5);
        printf("Enter the ID to  remove:");
        scanf("%d",&d);
        fp=fopen("stf.dat","r+");
        rewind(fp);
        while(fread(&a,sizeof(a),1,fp)==1)
        {
            if(a.id==d)
            {
                gotoxy(10,7);
                printf("The record is available");
                gotoxy(10,8);
                printf("Name is %s",a.name);
                gotoxy(10,9);
                findstaff='t';
            }
        }
        if(findstaff!='t')
        {
            gotoxy(10,10);
            printf("No record is found modify the search");
            if(getch())
                mainmenu();
        }
        if(findstaff=='t' )
        {
            gotoxy(10,9);
            printf("Do you want to delete it?(Y/N):");
            if(getch()=='y')
            {
                ft=fopen("test.dat","w+");
                rewind(fp);
                while(fread(&a,sizeof(a),1,fp)==1)
                {
                    if(a.id!=d)
                    {
                        fseek(ft,0,SEEK_CUR);
                        fwrite(&a,sizeof(a),1,ft);
                    }
                }
                fclose(ft);
                fclose(fp);
                remove("stf.dat");


                rename("test.dat","stf.dat");

                remove("test.text");
                fp=fopen("stf.dat","r+");
                if(findstaff=='t')
                {
                    gotoxy(10,10);
                    printf("The record is successfully deleted");
                    gotoxy(10,11);
                    printf("\n\tDelete another record?(Y/N)");
                }
            }
            else
                mainmenu();
            fflush(stdin);
            another=getch();
        }
    }
    gotoxy(10,15);
    mainmenu();
}
