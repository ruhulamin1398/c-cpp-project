
int checkid(int t)
{

        fseek(fp,0,SEEK_SET);
    rewind(fp);
    while(fread(&a,sizeof(a),1,fp)==1)
        if(a.id==t)
            return 0;
    return 1;
}

int getdata()

{
    int t;
    gotoxy(20,3);
    printf("Enter the Information Below");
    gotoxy(20,4);
    printf("Category:");
    gotoxy(31,5);
    printf("%s",catagories[s-1]);
    gotoxy(21,6);
    printf("ID:\t");
    gotoxy(30,6);
    scanf("%d",&t);
    if(checkid(t) == 0)
    {
        gotoxy(21,13);
        printf("\aThe id already exists\a");
        getch();
        mainmenu();
        return 0;
    }
    a.id=t;
    gotoxy(21,7),printf("Name:");
    gotoxy(33,7);
    scanf("%s",a.name);
    gotoxy(21,8);
    printf("Address:");
    gotoxy(30,8);
    scanf("%s",a.Address);
    gotoxy(21,9);
    printf("Contact:");
    gotoxy(31,9);
    scanf("%i",&a.contact);
    gotoxy(21,10);
    printf("Member Since:");
    scanf("%s",&a.membersince);
    gotoxy(31,17);
    return 1;
}




void addstaff(void)
{
    system("cls");
    int i;
    gotoxy(20,5);
    printf("SELECT CATEGORIES");
    gotoxy(20,7);
    printf("<1> New Member");
    gotoxy(20,9);
    printf("<2> Coach");
    gotoxy(20,11);
    printf("<3> Staff");
    gotoxy(20,13);
    printf("<4> Back to main menu");
    gotoxy(20,21);
    printf("Enter your choice:");
    scanf("%d",&s);
    if(s==4)
        mainmenu() ;
    system("cls");
    fp=fopen("stf.dat","ab+");
    if(getdata()==1)

    {
        a.cat=catagories[s-1];
        fseek(fp,0,SEEK_END);
        fwrite(&a,sizeof(a),1,fp);
        fclose(fp);
        gotoxy(21,14);
        printf("The record is Successfully saved");
        gotoxy(21,15);
        printf("Save any more?(Y / N):");
        if(getch()=='n')
            mainmenu();
        else
            system("cls");
        addstaff();
    }
}


