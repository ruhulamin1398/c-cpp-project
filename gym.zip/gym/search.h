

void searchstaff()
{
    system("cls");
    int d;
    printf("\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdbSearch Member\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb\xdb");
    gotoxy(20,10);
    printf("1. Search By ID");
    gotoxy(20,14);
    printf("2. Search By Name");
    gotoxy( 15,20);
    printf("Enter Your Choice");
    fp=fopen("stf.dat","rb+");
    rewind(fp);
    switch(getch())
    {
    case '1':
    {
        system("cls");
        gotoxy(25,4);
        printf("\xdb\xdb\xdb\xdb\xdb\xdbSearch By Id\xdb\xdb\xdb\xdb\xdb\xdb");
        gotoxy(20,5);
        printf("Enter the id:");
        scanf("%d",&d);
        gotoxy(20,7);
        while(fread(&a,sizeof(a),1,fp)==1)
        {
            if(a.id==d)
            {
                Sleep(2);
                gotoxy(20,6);
                printf("The Record is available\n");
                gotoxy(20,8);
                printf("ID:%d",a.id);
                gotoxy(20,9);
                printf("Category:%s",a.cat);
                gotoxy(20,10);
                printf("Name:%s",a.name);
                gotoxy(20,11);
                printf("Address:%s ",a.Address);
                gotoxy(20,12);
                printf("Contact:%i ",a.contact);
                gotoxy(20,13);
                printf("Member Since:%s",a.membersince);
                findstaff='t';
            }
        }
        if(findstaff!='t')
        {
            printf("\aNo Record Found");
        }
        gotoxy(20,17);
        printf("Try another search?(Y/N)");
        if(getch()=='y')
            searchstaff();
        else
            mainmenu();
        break;
    }
    case '2':
    {
        char s[15];
        system("cls");
        gotoxy(25,4);
        printf("\xdb\xdb\xdb\xdb\xdb\xdbSearch Record By Name\xdb\xdb\xdb\xdb\xdb\xdb");
        gotoxy(20,5);
        printf("Enter the Name:");
        scanf("%s",s);
        int d=0;
        while(fread(&a,sizeof(a),1,fp)==1)
        {
            if(strcmp(a.name,(s))==0)
            {
                gotoxy(20,d+7);
                //printf("The Staff is available");
                gotoxy(20,d+8);
                printf("ID:%d",a.id);
                gotoxy(20,d+10);
                printf("Name:%s",a.name);
                gotoxy(20,d+11);
                printf("Address:%s",a.Address);
                gotoxy(20,d+12);
                printf("Contact:%i",a.contact);
                gotoxy(20,d+13);
                printf("Member Since:%s",a.membersince);
                gotoxy(20,d+14);
                getch();
                d+=6;
            }
        }
        if(d==0)
            printf("\aNo Record Found");
        gotoxy(20,d+11);
        printf("Try another search?(Y/N)");
        if(getch()=='y')
            searchstaff();
        else
            mainmenu();
        break;
    }
    default :
        getch();
        searchstaff();
    }
    fclose(fp);
}
