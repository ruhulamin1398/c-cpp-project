struct ticket{

    char name[101] ;
    int id=0;
    char phone[101] ;
   char moviename[101];
    char time[101]="6 PM";
    int price=400;
    char date[101];
};
struct movie{
    int id=0;
    char moviename[101];
    char date[101];
};
