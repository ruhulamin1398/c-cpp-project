void ScoreBord()
{

    system("cls");

    cout<<"\t\t\t\t\t----- Score Board -----"<<endl<<endl<<endl;

    FILE *fp;
    struct player p1;
    fp=fopen("player.txt","ab+");
    fseek(fp,0,SEEK_SET);

    while(fread(&p1,sizeof(p1),1,fp)==1)
    {
        if(p1.position==1)
        cout<<"\t-----******--------"<<endl;
        cout<<"Position : "<<p1.position<<" "<<p1.name<<"("<<p1.point<<")"<<endl;
    }
    fclose(fp);

cout<<endl<<endl;
cout<<endl<<endl<<"Press Any Key to Main Menu"<<endl;
getchar();
getchar();
        MainMenu();
}
