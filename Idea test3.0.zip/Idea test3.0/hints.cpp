
void hint(int n, int MaxInput, int MinInput,int Diff )
{


    cout <<endl<<endl;
    cout<<"\t\t\t\t\t ##### Hints #####"<<endl;

    int flag=0 ;

    for(int i = 2; i < n; i++)
    {
        if(n % i == 0)
        {
            flag=1;
            break;
        }
    }

    if (flag==0)
    {

        cout << "\t\t\t"<<"* "<<". Number is Prime."<<endl;

    }
    else
    {

        if( n%2==0)
        {

            cout << "\t\t\t"<<"* "<<". Number is Even."<<endl;

        }
        else
        {
            cout << "\t\t\t"<<"* "<<". Number is Odd."<<endl;

        }

        if( n%3==0)
        {

            cout << "\t\t\t"<<"* "<<". Number is Divided By 3."<<endl;

        }
        else
        {
            cout << "\t\t\t"<<"* "<<". Number doesn't Divided by 3."<<endl;
        }

        if( n%5==0)
        {
            cout << "\t\t\t"<<"* "<<". Number is Divided By 5."<<endl;

        }
        else
        {
            cout << "\t\t\t"<<"* "<<". Number doesn't Divided by 5."<<endl;

        }

    }

    if(n>( MinInput+MaxInput)/2)

        cout << "\t\t\t"<<"* "<<". Number is situated in last half."<<endl;
    else
        cout << "\t\t\t"<<"* "<<". Number is situated in first half."<<endl;

    return ;
}

